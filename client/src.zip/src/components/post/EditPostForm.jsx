

import { FaCubes, FaFeather, FaFeatherAlt, FaFileAlt, FaImage } from "react-icons/fa";


const EditPostForm = () => {






  return (
    <section>
      <div className="post-form !h-[90%]">
        <div className="w-full max-w-lg mx-auto">
            <h1 className="font-roboto text-[1.3rem] font-light tracking-medium text-center text-primary mb-8">
                Edit Post Form
            </h1>

            <form>
                <div className="flex flex-col mb-6 w-full">
                    <label htmlFor="title" className="label"> <FaFeather /> Title
                    </label>
                    <input type="text" id="title" placeholder="Enter Title"
                        className={`placeholder:text-[#bec6d3] placeholder:font-light text-input-reg `}
                    />
                </div>

                <div className="flex flex-col mb-6 w-full">
                    <label htmlFor="body" className="label"> <FaFileAlt /> Body
                    </label>
                    <textarea rows={2} id="body" placeholder="Enter body"
                        className={`placeholder:text-[#bec6d3] placeholder:font-light text-input-reg `}
                    ></textarea>
                </div>

                <div className="flex flex-col mb-6 w-full">
                    <label htmlFor="categories" className="label"> <FaCubes /> Category
                    </label>
                    <select id="categories" className={`placeholder:text-[#bec6d3] placeholder:font-light text-input-reg`}
                        >
                            <option value=""></option>
                            {
                                <option > category name</option>
                            }
                    </select>
                </div>

                <div className="flex flex-col mb-6 w-full">
                    <label htmlFor="photo" className="label"> <FaImage /> Profile Photo </label>
                    <input type="file" id="photo" accept='.png, .jpeg, .jpg, .gif' className={`placeholder:text-dark-light text-input-reg`} />
                </div>

                <button type="submit" className="btn-dark-full " > 
                    <span className="flex items-center gap-2"> 
                        <FaFeatherAlt size={12} /> <span> Update Post </span>  
                      </span>  
                </button>

            </form>
        </div>
    </div>
    </section>
  )
}

export default EditPostForm
