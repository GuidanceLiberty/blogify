import React from 'react'
import Posts from './Posts'
import { FiSearch } from 'react-icons/fi'

const BlogList = () => {
  return (
    <section>
      <div className="header-div">
        <div className="post-header -mb-2 font-roboto text-xl font-light tracking-medium "> Viewing latest post </div>
        
        <div className="post-search !mr-5 w-full">
          <div className="flex justify-start items-center gap-2 rounded-xl w-full py-1 px-3 shadow-lg" >
              <FiSearch className=" w-6 h-6 text-[#959EAD]" />
              <input type='text' className='py-2 w-full focus:border-white outline-none placeholder:text-gray-500' placeholder='Search post ... ' />
            </div>
            
            
        </div>
      </div>


      <Posts limit={100} />
    </section>
  )
}

export default BlogList
