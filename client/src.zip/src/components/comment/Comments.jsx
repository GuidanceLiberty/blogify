import { FaRegCalendarAlt } from 'react-icons/fa';
import userImg from '../../assets/images/user.png';

const Comments = () => {
  return (
    <section>
        {
                <div className="comment-div">
                    <div className="comment-user-info">
                        <div className="user-img">
                            <img src={userImg} alt="user photo" className='w-10 h-10' />
                        </div>

                        <div className="user-info">
                            <span> comment author name</span>

                            <div className="flex items-center gap-1 !text-sm">
                                <FaRegCalendarAlt className='text-gray-400' /> 
                            </div>
                        </div>

                        
                    </div>

                    <p className="comment-content">
                        comment content
                    </p>
                </div>
        }
      
    </section>
  )
}

export default Comments
