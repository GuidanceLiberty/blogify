import MainLayOut from '../components/MainLayout'

const FAQ = () => {
  return (
    <MainLayOut>

    </MainLayOut>
  )
}

export default FAQ
