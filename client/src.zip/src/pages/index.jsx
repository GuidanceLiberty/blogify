import React from 'react'
import App from '../App'
import Navbar from '../components/Navbar'
import { Outlet } from 'react-router-dom'
import Footer from '../components/Footer'

const Index = () => {
  return (
    <main className=''>
      
    </main>
  )
}

export default Index
