import Hero from "../components/Hero"
import MainLayout from "../components/MainLayout"
import Posts from "../components/post/Posts"
import CallToAction from '../components/CallToAction'

const Home = () => {
  return (
    <MainLayout>
        <Hero />
        
        <Posts limit={6} />

        <CallToAction />
    </MainLayout>
  )
}

export default Home